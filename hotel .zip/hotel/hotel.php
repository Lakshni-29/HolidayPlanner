<?php
error_reporting(E_ALL ^ E_WARNING);
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://test.api.amadeus.com/v2/shopping/hotel-offers?cityCode=SEL&checkInDate=2022-02-25&checkOutDate=2022-03-06',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => array(
    'Authorization: Bearer AAIed4JL0HNfNIxndjvF2SofhpbL'
  ),
));

$response = curl_exec($curl);
curl_close($curl);
$decoded = json_decode($response);
$path=[];

$name = [];
$rating = [];
$distance = [];
$address = [];
$phone =[];
$description = [];
$category = [];
$bed = [];
$price = [];

for($i=0;$i
<sizeof($decoded->data);$i++)
{

$name[$i] = $decoded->data[$i]->hotel->name;
$rating[$i] = $decoded->data[$i]->hotel->rating;
$distance[$i] = $decoded->data[$i]->hotel->hotelDistance->distance;
$address[$i] = $decoded->data[$i]->hotel->address->lines[0];
$phone[$i] = $decoded->data[$i]->hotel->contact->phone;
$description[$i] = $decoded->data[$i]->hotel->description->text;
$category[$i] = $decoded->data[$i]->offers[0]->room->typeEstimated->category;
$bed[$i] = $decoded->data[$i]->offers[0]->room->typeEstimated->beds;
$price[$i] = $decoded->data[$i]->offers[0]->price->total;

}


echo $name;
echo $rating;
echo $distance;
echo $address;
echo $phone;
echo $description;
echo $category;
echo $bed;
echo $price;
?>


<link rel="stylesheet" href="hotel.css" />
